## Le modèle de boite
http://www-sop.inria.fr/members/Sylvain.Chevillard/fr.selfhtml.org/css/formats/affichage/modele_boite.png

## Le inline-block
http://fr.learnlayout.com/inline-block.html

## La propriété vertical-align
https://developer.mozilla.org/fr/docs/Web/CSS/vertical-align

## La propriété border-radius
https://developer.mozilla.org/fr/docs/Web/CSS/border-radius

## La propriété line-height
https://developer.mozilla.org/fr/docs/Web/CSS/line-height

## La propriété transition
https://developer.mozilla.org/fr/docs/Web/CSS/CSS_Transitions/Utiliser_transitions_CSS

## La figure
https://www.alsacreations.com/article/lire/1337-html5-elements-figure-et-figcaption.html